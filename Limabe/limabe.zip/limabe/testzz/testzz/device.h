#import <Foundation/Foundation.h>
@interface device : NSObject {

}


@end
