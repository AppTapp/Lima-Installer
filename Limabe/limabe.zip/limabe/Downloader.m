#import "Downloader.h"

@implementation Downloader
@synthesize strFileNameWithPath;
@synthesize delegate;
@end

