@interface NSString (RipdevExtensions)

- (NSString *)MD5Hash;

- (NSString*)hostName;

- (UIColor*)colorRepresentation;

@end
