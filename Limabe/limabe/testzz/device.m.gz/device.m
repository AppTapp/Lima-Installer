#import "device.h"
@implementation device

@end
