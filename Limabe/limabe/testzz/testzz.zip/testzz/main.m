#import <stdio.h>
#include <unistd.h>
#import "device.h"
#import "Downloader.h"
int main(int argc, char **argv, char **envp)
{
NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
NSLog(@"hello");
return 0;
[pool drain];
}

