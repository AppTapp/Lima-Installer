#import <Foundation/Foundation.h>
@protocol DownloaderDelegate;
@interface Downloader : NSObject {
}

@end
